# Final regression checks

The results below record the earlier project checks. The final review found a typo in the average-mileage report and an old archive, so report and archive results must be checked again after these fixes. Do not mark those final checks passed until they have been run on this version.

| ID | Feature | Test | Expected result | Previous result / current note |
|---|---|---|---|---|
| F5-01 | Startup | Start with the data file present | Menu opens | Passed previously |
| F5-02 | Startup | Temporarily remove the data file | Error and non-zero exit | Passed previously |
| F5-03 | Menu | Enter a blank or invalid choice | Message and menu repeats | Passed previously |
| F5-04 | Display | Display all cars | Headings and records appear | Passed previously |
| F5-05 | Search | Search for an existing registration | Matching record appears | Passed previously |
| F5-06 | Search | Enter a blank or missing registration | Error and return to menu | Passed previously |
| F5-07 | Add | Add a valid test car | One record is added | Passed previously in a temporary copy |
| F5-08 | Add | Try a duplicate or invalid record | Input is rejected; data stays unchanged | Duplicate test passed previously |
| F5-09 | Update | Confirm a valid rating change | Only the selected rating changes | Passed previously |
| F5-10 | Update | Enter an invalid rating or cancel | No unintended change | Passed previously |
| F5-11 | Export | Cancel the export prompt | Car remains active | Passed previously |
| F5-12 | Export | Confirm an export | Only selected car is moved to export file | Passed previously |
| F5-13 | Report | Create the Low rating report | Named report is created | Previously passed; rerun after the average-mileage fix |
| F5-14 | Report | Check all report sections | Metadata, summaries, average, exceptions and sorting appear | Rerun after the average-mileage fix |
| F5-15 | Backup | Create and list the archive | Archive contains current project files | Rebuilt archive listing showed current code, data, reports, documentation, README and AI use note | Pass
| F5-16 | Exit | Select Exit | Program closes | Passed previously |

## Final file review

The active WSL records file has 18 nonblank car records. The records have 10 fields, and registrations are unique. A previous copy had an extra blank line; that blank line has been removed from the active records file. The unused `recordsTest.txt` test copy has been removed from the active data folder.

## Still to record after final run

- Run the menu option for the report and check the average mileage section.
- Create a new archive and inspect its contents, including `README.md` and `AI_USAGE.md`.
- If demonstrating the empty-file error, do it using a separate temporary project copy, then restore the original data.