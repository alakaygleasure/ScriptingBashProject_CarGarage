# Project plan

## Project

Luxary Car Garage is a small Bash record system for employees at a used luxury car garage. It keeps the cars currently in the garage, recent imports and exports, and a report of cars with a Low market rating.

## Problem and intended user

Garage employees need to find a car by registration and keep its details and garage history together. They also need to record cars that enter or leave the garage and review cars that may need a price change or export.

## Record structure

The unique identifier is `CarReg`. Records are stored as comma-separated lines with 10 fields, in this order:

1. CarReg
2. CarBrand
3. Production_Year
4. NoOfOwners
5. CurrentMileage
6. PreviousGarageHistory
7. TimeInLot
8. FuelType
9. MarketRating
10. PriceEstimate

## Validation used

- Registration and the other required fields cannot be blank when adding a car.
- A registration already in the active records or import list is rejected.
- Fuel type must be Petrol, Diesel or Electric.
- Market rating can be Very High, High, Medium or Low.
- A production year later than the current year is rejected.
- Update and export need a registration that exists in the active records.
- Update and export ask for confirmation before changing the active file.

## Menu and report

The menu displays, searches, adds and exports cars, updates a car's rating, makes a backup and creates a Low rating report. The report includes its creation time and source, record count, counts by year and number of owners, average mileage, Low rating exceptions and cars sorted by brand.

The Low rating exception is a car whose market rating is `Low`.

## Safe file changes

The rating update writes a replacement file and moves it over the active records after confirmation. Export writes the selected record to `data/Exports.txt` and removes it from the active records after confirmation. Cancelled actions leave the active file alone.

The manual backup copies `data/records.txt` with a timestamp and makes a compressed project archive. The separate daily cron entry copies the active records to `backups/` once a day at midnight. It runs outside `project.sh`.

## Known limits

The records use commas as separators and are not a full CSV format, so a field must not contain a comma. Login details are currently examples stored in the script. The daily cron job uses the WSL user's home-folder path and runs only while the WSL cron service is available.