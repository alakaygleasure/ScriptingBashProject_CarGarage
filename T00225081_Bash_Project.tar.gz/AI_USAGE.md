# AI use declaration

I used AI to understand Bash commands, find reference pages and help write and fix parts of the project. This included code and troubleshooting for the menu, record updates and exports, the report and average mileage, backups, and the daily cron entry. AI gave me the cron command and suggested checking the service with `service cron status`.

I am responsible for understanding the finished project and checking it before I submit it. I have left this note here to explain the help I used.