# Luxary Car Garage

Student: Alex Gleasure  
Student number: T00225081

## Purpose

This Bash program helps garage employees keep car records. Each car has a registration, make, year, owners, mileage, garage history, time in the garage, fuel type, market rating and estimated price.

## Run the program

Open a terminal in the project folder and run:

```bash
bash project.sh
```

The login currently uses the values set near the top of `project.sh`: employee ID `employee1` and password `1234`.

## Menu

1. Display all cars.
2. Search by registration.
3. Add an imported car.
4. Show cars rated Low.
5. View recent imported cars.
6. Export a car. The car is added to the export file and removed from the active records.
7. Update a car's market rating.
8. Make a records copy and compressed project archive.
9. Create the Low rating report.
10. Exit.

## Data files

`data/records.txt` contains the active cars. Each line has 10 comma-separated fields in this order:

`CarReg, CarBrand, Production_Year, NoOfOwners, CurrentMileage, PreviousGarageHistory, TimeInLot, FuelType, MarketRating, PriceEstimate`

New cars are also listed in `data/CarImportsRecords.txt`. Exported cars are saved in `data/Exports.txt`.

## Reports and backups

Activity entries and Low rating reports are saved in `reports/`. A manual backup makes a timestamped copy of the active records and a `.tar.gz` archive in `backups/`. The archive contains the script, data, reports, documentation, README and AI use note. Daily copies are also scheduled separately in the user's WSL crontab; the cron entry is not part of the Bash script.

## Notes

The records are plain text with commas between fields, so commas should not be typed inside a field. The employee ID and password are examples stored in the script and should be changed for real use.